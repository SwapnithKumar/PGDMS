using Aspose.Words;

var doc = new Document("Input.docx");
doc.Save("Output.pdf");